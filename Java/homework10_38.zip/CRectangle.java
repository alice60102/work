class CRectangle
{
    private int length;
    private int width;

    void show()
    {
        System.out.print("length = "+length);
        System.out.println(",width = "+width);
    }

    CRectangle()
    {
     length = 2;
     width = 2;
    }

    CRectangle(int l,int w)
    {
     length = l;
     width = w;
    }

    void setCRectangle(int l,int w)
    {
     length = l;
     width = w;
    }

    void carea()
    {
        System.out.println("area = "+length*width);
    }
}