class homework10_38
{
 public static void main(String[] aru)
 {
   
   CData obj1=new CData();
   CData obj2=new CData(5,3);
   obj1.area();
   obj2.area();
 }
}