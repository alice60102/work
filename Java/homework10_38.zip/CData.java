class CData extends CRectangle
{
CData()
    {
        super();
    }

 CData(int l,int w)
    {
        super();
        setCRectangle(l,w);
    }

 void area()
 {  
    carea();
    show();
 }
}